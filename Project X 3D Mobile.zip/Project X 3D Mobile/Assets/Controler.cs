﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controler : MonoBehaviour
{
    public float speed;
    public float jump;
    private float moveInput;

    public Joystick joystick;

    private Rigidbody rb;

    private bool facinRight = true;

    private bool isGrounded;
    public Transform feetPos;
    public float checkRadius;
    public LayerMask whaatIsGround;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    private void Update()
    {
        float verticalMove = joystick.Vertical;
        isGrounded = Physics2D.OverlapCircle(feetPos.position, checkRadius, whaatIsGround);

       
    }

    private void FixedUpdate()
    {
        moveInput = joystick.Horizontal;
        rb.velocity = new Vector3(moveInput * speed, rb.velocity.y);

        if(facinRight == false && moveInput > 0)
        {
            Flip();
        }
        else if (facinRight == true && moveInput < 0)
        {
            Flip();
        }
    }

    public void OnJumpButtonDown()
    {
        if (isGrounded == true)
        {
            rb.velocity = Vector3.up * jump;
        }
    }
    
    void Flip()
    {
        facinRight = !facinRight;
        Vector3 Scaler = transform.localScale;
        Scaler.x *= -1;
        transform.localScale = Scaler;
    }
}
